const fs = require('fs');
const path = require('path');

class CheckController {
    constructor(app) {
        this.app = app;
        
        app.get('/historico-completo', (req, res) => {
            const usuarioId = req.session?.usuario?.id || 'anonimo';
            const filePath = path.join(__dirname, '../data', usuarioId.toString(), 'conformidade.json');
            let conformidade = {};
        
            if (fs.existsSync(filePath)) {
                try {
                    conformidade = JSON.parse(fs.readFileSync(filePath, 'utf8'));
                } catch (e) {
                    console.error('Erro ao ler conformidade:', e);
                }
            }
        
            // Carregar fotos recentes
            const uploadsDir = path.join(__dirname, '../views/public/uploads');
            let fotosRecentes = [];
        
            if (fs.existsSync(uploadsDir)) {
                const allFiles = fs.readdirSync(uploadsDir);
        
                fotosRecentes = allFiles
                    .filter(file => file.match(/\.(jpg|jpeg|png|gif)$/i) && file.includes(`foto-${usuarioId}-`))
                    .map(file => {
                        const filePath = path.join(uploadsDir, file);
                        const stats = fs.statSync(filePath);
                        return {
                            filename: file,
                            url: `/uploads/${file}`,
                            date: stats.mtime
                        };
                    })
                    .sort((a, b) => b.date - a.date)
                    .slice(0, 3);
            }
        
            res.render('Historico/historico-completo', { conformidade, fotosRecentes });
        });                    

        app.post('/upload', (req, res) => {
            const { image } = req.body;
            const base64Data = image.replace(/^data:image\/png;base64,/, "");
            
            // Obter ID do usuário da sessão
            const usuarioId = req.session?.usuario?.id || 'anonimo';
            const timestamp = Date.now();
            const filename = `foto-${usuarioId}-${timestamp}.png`;
            const savePath = path.join(__dirname, '../views/public/uploads', filename);

            fs.writeFile(savePath, base64Data, 'base64', (err) => {
                if (err) {
                    console.error(err);
                    return res.status(500).send("Erro ao salvar imagem");
                }

                res.status(200).json({ 
                    message: "Imagem salva com sucesso", 
                    filename,
                    usuarioId 
                });
            });
        });

        // Rota para obter as últimas fotos do usuário específico
        app.get('/api/fotos-recentes', (req, res) => {
            const uploadsDir = path.join(__dirname, '../views/public/uploads');
            const usuarioId = req.session?.usuario?.id || 'anonimo';
            
            fs.readdir(uploadsDir, (err, files) => {
                if (err) {
                    return res.status(500).json({ error: 'Erro ao ler diretório de uploads' });
                }

                // Filtrar apenas arquivos de imagem do usuário específico e ordenar por data de modificação
                const imageFiles = files
                    .filter(file => {
                        const isImage = file.match(/\.(jpg|jpeg|png|gif)$/i);
                        const isUserFile = file.includes(`foto-${usuarioId}-`) || usuarioId === 'anonimo';
                        return isImage && isUserFile;
                    })
                    .map(file => {
                        const filePath = path.join(uploadsDir, file);
                        const stats = fs.statSync(filePath);
                        return {
                            filename: file,
                            path: `/uploads/${file}`,
                            date: stats.mtime
                        };
                    })
                    .sort((a, b) => b.date - a.date)
                    .slice(0, 3); // Pegar apenas as 3 mais recentes

                res.json(imageFiles);
            });
        });

        // Rota para salvar dados de conformidade no servidor
        app.post('/api/conformidade', (req, res) => {
            const { data, status } = req.body;
            const usuarioId = req.session?.usuario?.id || 'anonimo';
            
            // Criar diretório de dados do usuário se não existir
            const userDataDir = path.join(__dirname, '../data', usuarioId.toString());
            if (!fs.existsSync(userDataDir)) {
                fs.mkdirSync(userDataDir, { recursive: true });
            }
            
            // Salvar dados de conformidade
            const conformidadeFile = path.join(userDataDir, 'conformidade.json');
            let conformidadeData = {};
            
            if (fs.existsSync(conformidadeFile)) {
                try {
                    conformidadeData = JSON.parse(fs.readFileSync(conformidadeFile, 'utf8'));
                } catch (error) {
                    console.error('Erro ao ler arquivo de conformidade:', error);
                }
            }
            
            conformidadeData[data] = status;
            
            fs.writeFileSync(conformidadeFile, JSON.stringify(conformidadeData, null, 2));
            
            res.json({ success: true });
        });

        // Rota para obter dados de conformidade do usuário
        app.get('/api/conformidade', (req, res) => {
            const usuarioId = req.session?.usuario?.id || 'anonimo';
            const conformidadeFile = path.join(__dirname, '../data', usuarioId.toString(), 'conformidade.json');
            
            if (fs.existsSync(conformidadeFile)) {
                try {
                    const conformidadeData = JSON.parse(fs.readFileSync(conformidadeFile, 'utf8'));
                    res.json(conformidadeData);
                } catch (error) {
                    console.error('Erro ao ler arquivo de conformidade:', error);
                    res.json({});
                }
            } else {
                res.json({});
            }
        });
    }
}

module.exports = CheckController;