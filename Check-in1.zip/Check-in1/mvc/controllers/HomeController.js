class HomeController
{
    constructor(app)
    {
        app.get("/", (req, res) => 
            {
                res.render("Auth/index", {
                    invalido: "",
                    senhaInvalida: "",
                    usuarioInvalido: ""
                })
        })
        app.get("/check", (req, res) => {
            res.render("Check-In/check-in")
        })
        app.get("/historico", (req, res) => {
            res.render("Historico/historico")
        }) 
    }
}

module.exports = HomeController