const AuthModel = require("../model/AuthModel")

class AuthController 
{

    constructor(app)
    {
        // Middleware para configurar sessões simples
        app.use((req, res, next) => {
            if (!req.session) {
                req.session = {};
            }
            next();
        });

        app.post("/auth", async (req, res) => 
        {

            const usuario = req.body.usuario.replace(/\D/g, ''); // Remove . e -
            const senha = req.body.senha

            const auth = new AuthModel(usuario, senha)

            const resultado = await auth.login()

            if(resultado.sucesso) 
            {
                // Salvar informações do usuário na sessão
                req.session.usuario = resultado.usuario;
                res.render("Check-In/check-in", { usuario: resultado.usuario })
            }
            else
            {
                // Renderiza novamente o login com os erros recebidos
                res.render("Auth/index", {
                    invalido: resultado.invalido || "",
                    senhaInvalida: resultado.senhaInvalida || "",
                    usuarioInvalido: resultado.usuarioInvalido || ""
                })
            }
        })

        // Rota para logout
        app.post("/logout", (req, res) => {
            req.session = null;
            res.redirect("/");
        });

        // Middleware para verificar autenticação
        app.use("/check", (req, res, next) => {
            if (!req.session.usuario) {
                return res.redirect("/");
            }
            next();
        });

        app.use("/historico", (req, res, next) => {
            if (!req.session.usuario) {
                return res.redirect("/");
            }
            next();
        });
    }
}

module.exports = AuthController