// Função para obter o status de conformidade de uma data específica do servidor
async function obterStatusConformidadeServidor() {
  try {
    const response = await fetch('/api/conformidade');
    return await response.json();
  } catch (error) {
    console.error('Erro ao carregar conformidade do servidor:', error);
    return {};
  }
}

// Função para obter o status de conformidade de uma data específica (fallback para localStorage)
function obterStatusConformidade(data) {
    const dataString = data.toDateString();
    return localStorage.getItem('conformidade_' + dataString) === 'true';
}

// Função para atualizar o calendário da semana
async function atualizarCalendario() {
    const hoje = new Date();
    const diasSemana = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'];
    const meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 
                   'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
    
    // Atualizar mês atual
    document.getElementById('mesAtual').textContent = meses[hoje.getMonth()] + ', ' + hoje.getDate();
    
    // Obter dados de conformidade do servidor
    const conformidadeServidor = await obterStatusConformidadeServidor();
    
    // Obter o início da semana (segunda-feira)
    const inicioSemana = new Date(hoje);
    const diaSemana = hoje.getDay();
    const diasParaSegunda = diaSemana === 0 ? -6 : 1 - diaSemana;
    inicioSemana.setDate(hoje.getDate() + diasParaSegunda);
    
    // Atualizar status de cada dia da semana
    const statusElements = ['statusSeg', 'statusTer', 'statusQua', 'statusQui', 'statusSex'];
    
    for (let i = 0; i < 5; i++) {
        const dataAtual = new Date(inicioSemana);
        dataAtual.setDate(inicioSemana.getDate() + i);
        
        // Verificar primeiro no servidor, depois no localStorage
        const dataString = dataAtual.toDateString();
        const temConformidadeServidor = conformidadeServidor[dataString];
        const temConformidadeLocal = obterStatusConformidade(dataAtual);
        const temConformidade = temConformidadeServidor || temConformidadeLocal;
        
        const elemento = document.getElementById(statusElements[i]);
        elemento.textContent = temConformidade ? '✅' : '❌';
    }
    
    // Atualizar status de hoje
    const hojeString = hoje.toDateString();
    const temConformidadeHojeServidor = conformidadeServidor[hojeString];
    const temConformidadeHojeLocal = obterStatusConformidade(hoje);
    const temConformidadeHoje = temConformidadeHojeServidor || temConformidadeHojeLocal;
    
    document.getElementById('statusHoje').textContent = 'Hoje: ' + (temConformidadeHoje ? '✅' : '❌');
}

// Função para carregar fotos recentes
async function carregarFotosRecentes() {
    try {
        const response = await fetch('/api/fotos-recentes');
        const fotos = await response.json();
        
        const container = document.getElementById('fotosRecentes');
        container.innerHTML = '';
        
        if (fotos.length === 0) {
            container.innerHTML = '<p class="text-white">Nenhuma foto encontrada</p>';
            return;
        }
        
        fotos.forEach(foto => {
            const figure = document.createElement('figure');
            const img = document.createElement('img');
            img.src = foto.path;
            img.className = 'size-24 rounded-full object-cover';
            img.alt = 'Foto de check-in';
            
            // Adicionar evento de clique para visualizar a foto em tamanho maior
            img.addEventListener('click', () => {
                const modal = document.createElement('div');
                modal.className = 'fixed top-0 left-0 w-full h-full bg-black bg-opacity-75 flex items-center justify-center z-50';
                modal.innerHTML = `
                    <div class="relative">
                        <img src="${foto.path}" class="max-w-full max-h-full">
                        <button class="absolute top-2 right-2 text-white text-2xl bg-red-500 rounded-full w-8 h-8 flex items-center justify-center" onclick="this.parentElement.parentElement.remove()">×</button>
                    </div>
                `;
                document.body.appendChild(modal);
            });
            
            figure.appendChild(img);
            container.appendChild(figure);
        });
    } catch (error) {
        console.error('Erro ao carregar fotos:', error);
        document.getElementById('fotosRecentes').innerHTML = '<p class="text-white">Erro ao carregar fotos</p>';
    }
}

// Carregar dados quando a página for carregada
window.addEventListener('load', () => {
    atualizarCalendario();
    carregarFotosRecentes();
});

