const abrirBtn = document.getElementById('abrirCamera');
const cameraTela = document.getElementById('cameraTela');
const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const capturarBtn = document.getElementById('capturar');
const confirmarBtn = document.getElementById('confirmar');
const cancelarBtn = document.getElementById('cancelar');
const conformidadeBtn = document.getElementById('conformidadeBtn');
const fotoCheckbox = document.getElementById('fotoCheckbox');
const ultimaFotoData = document.getElementById('ultimaFotoData');

let stream;
let fotoCapturada = false;

// Função para verificar se todos os checkboxes estão marcados
function verificarConformidade() {
  const episCheckboxes = document.querySelectorAll('.epi-checkbox');
  const todosEpisMarcados = Array.from(episCheckboxes).every(checkbox => checkbox.checked);
  
  if (todosEpisMarcados && fotoCapturada) {
    conformidadeBtn.disabled = false;
    conformidadeBtn.classList.remove('bg-gray-300', 'cursor-not-allowed');
    conformidadeBtn.classList.add('bg-green-500', 'text-white', 'cursor-pointer');
  } else {
    conformidadeBtn.disabled = true;
    conformidadeBtn.classList.add('bg-gray-300', 'cursor-not-allowed');
    conformidadeBtn.classList.remove('bg-green-500', 'text-white', 'cursor-pointer');
  }
}

// Adicionar event listeners aos checkboxes dos EPIs
document.querySelectorAll('.epi-checkbox').forEach(checkbox => {
  checkbox.addEventListener('change', verificarConformidade);
});

// Função para atualizar a data da última foto
function atualizarUltimaFoto() {
  const agora = new Date();
  const diasSemana = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
  const diaSemana = diasSemana[agora.getDay()];
  const dataFormatada = agora.toLocaleDateString('pt-BR') + ' - ' + agora.toLocaleTimeString('pt-BR', {hour: '2-digit', minute: '2-digit'}) + ' - ' + diaSemana;
  
  ultimaFotoData.textContent = dataFormatada;
  fotoCheckbox.checked = true;
  fotoCapturada = true;
  verificarConformidade();
  
  // Salvar no localStorage e no servidor
  localStorage.setItem('ultimaFotoData', dataFormatada);
  localStorage.setItem('fotoCapturada', 'true');
}

// Função para salvar conformidade no servidor
async function salvarConformidadeServidor(data, status) {
  try {
    await fetch('/api/conformidade', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ data, status })
    });
  } catch (error) {
    console.error('Erro ao salvar conformidade no servidor:', error);
  }
}

// Função para carregar dados de conformidade do servidor
async function carregarConformidadeServidor() {
  try {
    const response = await fetch('/api/conformidade');
    const conformidadeData = await response.json();
    
    // Verificar se há conformidade para hoje
    const hoje = new Date().toDateString();
    if (conformidadeData[hoje]) {
      const fotoSalva = localStorage.getItem('fotoCapturada');
      const dataSalva = localStorage.getItem('ultimaFotoData');
      
      if (fotoSalva === 'true' && dataSalva) {
        ultimaFotoData.textContent = dataSalva;
        fotoCheckbox.checked = true;
        fotoCapturada = true;
        verificarConformidade();
      }
    }
  } catch (error) {
    console.error('Erro ao carregar conformidade do servidor:', error);
  }
}

// Carregar dados salvos ao carregar a página
window.addEventListener('load', () => {
  carregarConformidadeServidor();
  
  const fotoSalva = localStorage.getItem('fotoCapturada');
  const dataSalva = localStorage.getItem('ultimaFotoData');
  
  if (fotoSalva === 'true' && dataSalva) {
    ultimaFotoData.textContent = dataSalva;
    fotoCheckbox.checked = true;
    fotoCapturada = true;
    verificarConformidade();
  }
});

abrirBtn.addEventListener('click', async () => {
  cameraTela.classList.remove('hidden');
  canvas.classList.add('hidden');
  confirmarBtn.classList.add('hidden');
  cancelarBtn.classList.add('hidden');
  capturarBtn.classList.remove('hidden');

  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: true });
    video.srcObject = stream;
  } catch (error) {
    alert('Erro ao acessar a câmera: ' + error.message);
  }
});

capturarBtn.addEventListener('click', () => {
  const ctx = canvas.getContext('2d');
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  ctx.drawImage(video, 0, 0);
  canvas.classList.remove('hidden');

  // Pausa o vídeo, mostra botões de confirmar/cancelar
  video.pause();
  confirmarBtn.classList.remove('hidden');
  cancelarBtn.classList.remove('hidden');
  capturarBtn.classList.add('hidden');
});

cancelarBtn.addEventListener('click', () => {
  video.play();
  canvas.classList.add('hidden');
  confirmarBtn.classList.add('hidden');
  cancelarBtn.classList.add('hidden');
  capturarBtn.classList.remove('hidden');
});

confirmarBtn.addEventListener('click', () => {
  const imagemBase64 = canvas.toDataURL('image/png');

  fetch('/upload', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ image: imagemBase64 })
  }).then(() => {
    alert('Imagem enviada!');
    atualizarUltimaFoto();
    stream.getTracks().forEach(track => track.stop());
    cameraTela.classList.add('hidden');
  }).catch(err => alert('Erro ao enviar: ' + err.message));
});

// Event listener para o botão de conformidade
conformidadeBtn.addEventListener('click', async () => {
  if (!conformidadeBtn.disabled) {
    // Salvar status de conformidade
    const agora = new Date();
    const dataConformidade = agora.toDateString();
    
    // Salvar no localStorage
    localStorage.setItem('conformidade_' + dataConformidade, 'true');
    
    // Salvar no servidor
    await salvarConformidadeServidor(dataConformidade, true);
    
    alert('Check-in realizado com sucesso!');
    window.location.href = '/historico';
  }
});