const express = require("express")
const path = require("path")
const HomeController = require("./mvc/controllers/HomeController")
const AuthController = require("./mvc/controllers/AuthController")
const CheckController = require("./mvc/controllers/CheckController")

class Server
{

    app
    porta = 3000
    
    constructor()
    {
        this.app = express()
        this.porta = 3000
        this.on()

        this.configurarViewEngine()
        this.configurarRotas()
    }

    configurarViewEngine() 
    {
        this.app.set("view engine", "ejs")
        this.app.set("views", "mvc/views")
        this.app.use(express.urlencoded({ extended: true, limit: '10mb' }));
        this.app.use(express.json({ limit: '10mb' }));
        this.app.use(express.static(path.join(__dirname, 'mvc/views/public')));
    }

    configurarRotas() {
        new HomeController(this.app)
        new AuthController(this.app)
        new CheckController(this.app)
    }

    on()
    {
        this.app.listen(this.porta)
    }
}

new Server()
